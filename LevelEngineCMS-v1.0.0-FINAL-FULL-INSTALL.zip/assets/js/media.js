window.leT??=(text)=>text;
(()=>{
  document.querySelector('[data-thumbnail-clear]')?.addEventListener('click',()=>{
    const field=document.getElementById('existing-thumbnail'),preview=document.getElementById('thumbnail-preview');
    if(field)field.value='';if(preview){preview.removeAttribute('src');preview.hidden=true}
    const file=document.querySelector('input[name="thumbnail"]');if(file)file.value='';
  });
  const dialog=document.getElementById('media-dialog');if(!dialog)return;
  const grid=dialog.querySelector('[data-media-grid]'),message=dialog.querySelector('[data-media-message]');
  const fileInput=dialog.querySelector('[data-media-files]'),drop=dialog.querySelector('[data-media-drop]');
  const search=dialog.querySelector('[data-media-search]'),alt=dialog.querySelector('[data-media-alt]');
  const insert=dialog.querySelector('[data-media-insert]'),more=dialog.querySelector('[data-media-more]');
  const selectedLabel=dialog.querySelector('[data-media-selected]'),editor=document.querySelector('[data-le-editor="full"] textarea');
  let mode='content',selected=null,offset=0,generation=0,uploading=false,uploaded=false,searchTimer,trigger;
  let selection={start:0,end:0};
  const validPath=path=>typeof path==='string'&&/^\/uploads\/(media|posts|gallery|avatars)\/[a-zA-Z0-9._-]+\.(jpg|jpeg|png|gif|webp)$/i.test(path);
  const say=(text,error=false)=>{message.textContent=text;message.classList.toggle('media-error',error)};
  const select=item=>{
    selected=item;alt.value=item.alt_text||'';insert.disabled=false;selectedLabel.textContent=item.title||leT("Obrazek");
    grid.querySelectorAll('[data-media-id]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mediaId===String(item.id))));
  };
  const card=item=>{
    if(!validPath(item.path))return;
    const b=document.createElement('button');b.type='button';b.className='media-picker-card';b.dataset.mediaId=String(item.id);
    b.setAttribute('aria-pressed',String(selected?.id===item.id));b.setAttribute('aria-label',leT("Wybierz ")+(item.title||'obrazek'));
    const img=document.createElement('img');img.src=item.path;img.alt=item.alt_text||'';img.loading='lazy';
    const title=document.createElement('strong');title.textContent=item.title||leT("Bez tytułu");
    const meta=document.createElement('small');meta.textContent=Math.ceil(Number(item.size_bytes||0)/1024)+' KB';
    b.append(img,title,meta);b.addEventListener('click',()=>select(item));grid.append(b);
  };
  async function api(url,options={}){
    const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),30000);
    try{
      const response=await fetch(url,{...options,credentials:'same-origin',cache:'no-store',signal:controller.signal});
      let data;try{data=await response.json()}catch(e){throw new Error(leT("Hosting nie zwrócił poprawnej odpowiedzi. Sprawdź limit uploadu lub zaloguj się ponownie."))}
      if(!response.ok||!data.ok)throw new Error(data.error||leT("Nie udało się połączyć z biblioteką."));return data;
    }catch(e){if(e.name==='AbortError')throw new Error(leT("Przesyłanie trwało zbyt długo. Sprawdź połączenie i spróbuj ponownie."));throw e}
    finally{clearTimeout(timeout)}
  }
  async function load(append=false){
    const current=++generation;more.disabled=true;
    if(!append){offset=0;grid.replaceChildren();say(leT("Ładowanie biblioteki…"))}
    try{
      const url=dialog.dataset.endpoint+'?'+new URLSearchParams({q:search.value,offset:String(offset)});
      const data=await api(url);if(current!==generation)return;
      if(!Array.isArray(data.items))throw new Error(leT("Nieprawidłowa odpowiedź biblioteki."));
      data.items.forEach(card);offset=data.next_offset;more.hidden=!data.has_more;
      if(!uploading)say(grid.children.length?leT("Wybierz obrazek z biblioteki."):leT("Brak obrazków. Wgraj plik lub zmień wyszukiwanie."));
    }catch(e){if(current===generation)say(e.message,true)}finally{if(current===generation)more.disabled=false}
  }
  const close=()=>{
    dialog.close();trigger?.focus();
    if(mode==='library'&&uploaded&&!uploading)location.reload();
  };
  document.querySelectorAll('[data-media-open]').forEach(button=>button.addEventListener('click',()=>{
    trigger=button;mode=button.dataset.mediaOpen;selected=null;alt.value='';search.value='';insert.disabled=true;
    editor?.leEditorRemember?.();selection={start:editor?.selectionStart||0,end:editor?.selectionEnd||0};selectedLabel.textContent=leT("Wybierz obrazek.");
    dialog.querySelector('#media-dialog-title').textContent=mode==='thumbnail'?leT("Wybierz miniaturę Newsa"):mode==='library'?leT("Media Uploader"):leT("Dodaj obrazek do treści");
    insert.textContent=mode==='thumbnail'?leT("Ustaw miniaturę"):mode==='library'?leT("Kopiuj adres"):leT("Wstaw do treści");
    dialog.showModal();load();
  }));
  dialog.querySelectorAll('[data-media-close]').forEach(b=>b.addEventListener('click',close));
  dialog.addEventListener('cancel',e=>{e.preventDefault();close()});
  more.addEventListener('click',()=>load(true));
  search.addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>load(),250)});
  async function upload(files){
    if(uploading||!files.length)return;uploading=true;fileInput.disabled=true;search.disabled=true;insert.disabled=true;
    const failures=[];let count=0,last;
    for(const [i,file] of [...files].entries()){
      say(leT("Wgrywanie ")+(i+1)+' / '+files.length+': '+file.name);
      try{
        if(file.size>5*1024*1024)throw new Error(leT("maksymalnie 5 MB"));
        const body=new FormData();body.append('csrf',dialog.dataset.csrf);body.append('image',file);body.append('alt_text',alt.value);
        const data=await api(dialog.dataset.endpoint,{method:'POST',body});
        if(!data.item||!validPath(data.item.path))throw new Error(leT("nieprawidłowy adres obrazka"));
        count++;last=data.item;uploaded=true;
      }catch(e){failures.push(file.name+': '+e.message)}
    }
    search.value='';await load();uploading=false;fileInput.disabled=false;search.disabled=false;fileInput.value='';
    if(last)select(last);else insert.disabled=!selected;
    say((count?leT("Wgrane pliki: ")+count+'. ':'')+failures.join(' · '),failures.length>0);
  }
  fileInput.addEventListener('change',()=>upload(fileInput.files));
  ['dragenter','dragover'].forEach(type=>drop.addEventListener(type,e=>{e.preventDefault();drop.classList.add('dragover')}));
  ['dragleave','drop'].forEach(type=>drop.addEventListener(type,e=>{e.preventDefault();drop.classList.remove('dragover')}));
  drop.addEventListener('drop',e=>upload(e.dataTransfer.files));
  const escape=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
  insert.addEventListener('click',async()=>{
    if(!selected||!validPath(selected.path))return;
    if(mode==='library'){
      try{await navigator.clipboard.writeText(selected.path);say(leT("Adres obrazka został skopiowany."))}catch(e){window.prompt(leT("Skopiuj adres obrazka:"),selected.path)}return;
    }
    if(mode==='thumbnail'){
      const field=document.getElementById('existing-thumbnail'),preview=document.getElementById('thumbnail-preview');
      if(!field||!preview)return;field.value=selected.path;preview.src=selected.path;preview.hidden=false;
      const localFile=document.querySelector('input[name="thumbnail"]');if(localFile)localFile.value='';
    }else if(editor){
      dialog.close();
      const markdown=document.querySelector('[name="content_format"]')?.value==='markdown';
      const text=markdown?'!['+alt.value.replace(/[\\\[\]\r\n]/g,' ')+']('+selected.path+')':'<img src="'+escape(selected.path)+'" alt="'+escape(alt.value)+'">';
      if(editor.leEditorInsert){editor.setSelectionRange(selection.start,selection.end);editor.leEditorInsert(text)}else editor.setRangeText(text,selection.start,selection.end,'end');editor.dispatchEvent(new Event('input',{bubbles:true}));
    }
    close();if(mode==='content')editor?.focus();
  });
})();
