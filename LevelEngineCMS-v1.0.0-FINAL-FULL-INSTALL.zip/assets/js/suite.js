(() => {
  'use strict';
  const t=window.leT||((s)=>s);
  const form=[...document.forms].find(f=>['post_save','page_save'].includes(f.elements.action?.value));
  if(!form)return;
  const status=form.querySelector('[data-autosave-status]');
  let timer,saving=false,dirty=false,submitted=false;
  const say=text=>{if(status)status.textContent=text;};
  const kind=form.elements.kind.value,id=form.elements.id.value,route=new URL(location.href);
  if(id==='0'&&!route.searchParams.has('draft')){route.searchParams.set('draft',crypto.randomUUID());history.replaceState(null,'',route);}
  const localKey='levelengine-editor:'+document.body.dataset.adminUser+':'+kind+':'+(id==='0'?route.searchParams.get('draft'):id);
  const recoverLocal=document.createElement('button');recoverLocal.type='button';recoverLocal.className='btn';recoverLocal.textContent=t('Odzyskaj lokalną kopię');status?.parentElement.append(' ',recoverLocal);
  function fields(){
    const data=new FormData(form);data.set('action','suite_autosave');
    for(const [key,value] of [...data])if(value instanceof File)data.delete(key);
    form.querySelectorAll('input[type=checkbox][name]').forEach(input=>data.set(input.name,input.checked?input.value:'0'));
    return data;
  }
  async function save(){
    if(saving||!dirty||submitted)return;saving=true;dirty=false;
    try{
      const data=fields(),snapshot={};for(const [key,value] of data)if(!['csrf','action'].includes(key))snapshot[key]=value;
      try{localStorage.setItem(localKey,JSON.stringify({snapshot,at:Date.now()}));}catch{if(id==='0')throw new Error(t('Nie można zapisać lokalnej kopii. Zapisz szkic przyciskiem.'));}
      if(id==='0'){say(t('Lokalna kopia zapisana:')+' '+new Date().toLocaleTimeString());return;}
      const response=await fetch('/admin/suite-api.php',{method:'POST',body:data});const json=await response.json();if(!response.ok||!json.ok)throw new Error(json.error||t('Błąd zapisu'));say(t('Kopia robocza zapisana:')+' '+new Date().toLocaleTimeString());
    }
    catch(error){dirty=true;say(t('Kopia niezapisana:')+' '+error.message);}
    finally{saving=false;if(dirty&&!submitted)timer=setTimeout(save,5000);}
  }
  const schedule=()=>{dirty=true;clearTimeout(timer);timer=setTimeout(save,3000);};
  form.addEventListener('input',schedule);form.addEventListener('change',schedule);
  function applySnapshot(snapshot){
    if(snapshot.content_format&&form.elements.content_format){form.elements.content_format.value=snapshot.content_format;form.elements.content_format.dispatchEvent(new Event('change',{bubbles:true}));}
    for(const [key,value] of Object.entries(snapshot)){
      if(['action','csrf','edit_version','id','kind','content_format'].includes(key))continue;
      const input=form.elements.namedItem(key);if(!input||input instanceof RadioNodeList||input.type==='file')continue;
      if(input.type==='checkbox')input.checked=value===true||value==='1'||value===1;
      else if(key==='content'&&input.leEditorLoad)input.leEditorLoad(value??'');else input.value=value??'';
      input.dispatchEvent(new Event('input',{bubbles:true}));
    }
    const thumbnail=document.getElementById('thumbnail-preview');if(thumbnail&&form.elements.existing_thumbnail){const path=form.elements.existing_thumbnail.value;thumbnail.hidden=!path;if(path)thumbnail.src=path;else thumbnail.removeAttribute('src');}
    say(t('Kopia odzyskana. Sprawdź treść i zapisz.'));
  }
  recoverLocal.addEventListener('click',()=>{try{const saved=JSON.parse(localStorage.getItem(localKey)||'null');if(!saved?.snapshot)throw new Error(t('Brak lokalnej kopii.'));if(confirm(t('Zastąpić pola formularza ostatnią kopią roboczą?')))applySnapshot(saved.snapshot);}catch(error){say(error.message);}});
  if(id==='0'){const button=form.querySelector('[data-load-autosave]');if(button)button.disabled=true;}
  form.querySelector('[data-load-autosave]')?.addEventListener('click',async()=>{
    if(!confirm(t('Zastąpić pola formularza ostatnią kopią roboczą?')))return;
    try{
      const response=await fetch('/admin/suite-api.php?kind='+encodeURIComponent(form.elements.kind.value)+'&id='+encodeURIComponent(form.elements.id.value));
      const json=await response.json();if(!response.ok||!json.ok||!json.snapshot)throw new Error(json.error||t('Brak kopii'));
      applySnapshot(json.snapshot);
    }catch(error){say(error.message);}
  });
  form.addEventListener('submit',()=>{submitted=true;dirty=false;clearTimeout(timer);});
})();
