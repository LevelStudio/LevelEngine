(() => {
  'use strict';
  const t=window.leT||((text)=>text);
  const dialog=document.getElementById('admin-command');
  const input=document.getElementById('admin-command-input');
  const results=document.getElementById('admin-command-results');
  if(dialog&&input&&results){
    const links=JSON.parse(document.getElementById('admin-command-links').textContent);
    let timer,controller,opener,serial=0;
    const message=text=>{const p=document.createElement('p');p.textContent=t(text);results.replaceChildren(p);};
    function render(items){
      results.replaceChildren();
      if(!items.length){message('Brak wyników. Spróbuj innego hasła.');return;}
      for(const item of items){
        // Result URLs are local routes produced by the server.
        if(typeof item.url!=='string'||!item.url.startsWith('/')||item.url.startsWith('//'))continue;
        const a=document.createElement('a'),box=document.createElement('span'),title=document.createElement('strong'),detail=document.createElement('small'),arrow=document.createElement('span');
        a.href=item.url;title.textContent=item.title;detail.textContent=item.detail;arrow.textContent='↗';box.append(title,detail);a.append(box,arrow);results.append(a);
      }
    }
    function open(button){opener=button;input.value='';render(links);dialog.showModal();input.focus();}
    document.querySelectorAll('[data-command-open]').forEach(button=>button.addEventListener('click',()=>open(button)));
    dialog.querySelector('[data-command-close]').addEventListener('click',()=>dialog.close());
    dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}});
    dialog.addEventListener('close',()=>{clearTimeout(timer);controller?.abort();serial++;opener?.focus();});
    input.addEventListener('input',()=>{
      clearTimeout(timer);controller?.abort();const request=++serial;const term=input.value.trim();
      if(term.length<2){render(links);return;}
      message('Wyszukiwanie…');
      timer=setTimeout(async()=>{
        controller=new AbortController();
        try{const response=await fetch('/admin/search.php?q='+encodeURIComponent(term),{signal:controller.signal,headers:{Accept:'application/json'}});const json=await response.json();if(!response.ok||!json.ok)throw new Error();if(request===serial&&dialog.open)render(json.items);}
        catch(error){if(error.name!=='AbortError'&&request===serial)message('Nie udało się wyszukać. Spróbuj ponownie.');}
      },220);
    });
    dialog.addEventListener('keydown',event=>{
      const anchors=[...results.querySelectorAll('a')];const at=anchors.indexOf(document.activeElement);
      if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();if(!anchors.length)return;const next=at<0?(event.key==='ArrowDown'?0:anchors.length-1):(at+(event.key==='ArrowDown'?1:-1)+anchors.length)%anchors.length;anchors[next].focus();}
      if(event.key==='Enter'&&document.activeElement===input&&anchors[0]){event.preventDefault();anchors[0].click();}
    });
    document.addEventListener('keydown',event=>{if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){event.preventDefault();if(dialog.open)dialog.close();else open(document.querySelector('[data-command-open]'));}});
  }
  const compact=document.querySelector('[data-density-toggle]');
  const setDensity=enabled=>{document.body.classList.toggle('admin-compact',enabled);compact?.setAttribute('aria-pressed',String(enabled));};
  try{setDensity(localStorage.getItem('le-admin-density')==='compact');}catch{}
  compact?.addEventListener('click',()=>{const enabled=!document.body.classList.contains('admin-compact');setDensity(enabled);try{localStorage.setItem('le-admin-density',enabled?'compact':'comfortable');}catch{}});
  // Save shortcut in text editors; normal browser text undo remains untouched.
  document.addEventListener('keydown',event=>{if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='s'){const form=document.querySelector('.editor-grid');if(form){event.preventDefault();form.requestSubmit();}}});
  document.querySelectorAll('.editor-grid').forEach(form=>{
    let dirty=false,submitting=false;
    form.addEventListener('input',()=>dirty=true);form.addEventListener('change',()=>dirty=true);
    form.addEventListener('submit',()=>submitting=true);
    addEventListener('beforeunload',event=>{if(dirty&&!submitting){event.preventDefault();event.returnValue='';}});
  });
})();
