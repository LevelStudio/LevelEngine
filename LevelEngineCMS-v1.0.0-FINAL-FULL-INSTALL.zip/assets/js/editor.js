window.leT??=(text)=>text;
(()=>{
 const allowed=new Set('h1 h2 h3 h4 h5 h6 p div br strong b em i u s strike ul ol li a blockquote img hr code pre span'.split(' '));
 const clean=html=>{
  const doc=new DOMParser().parseFromString(html,'text/html');
  const visit=node=>{
   if(node.nodeType===3)return document.createTextNode(node.textContent);
   if(node.nodeType!==1||/^(script|style|iframe|object|embed|svg|math|template)$/.test(node.localName))return document.createDocumentFragment();
   const tag=node.localName,el=allowed.has(tag)?document.createElement(({b:'strong',i:'em',strike:'s'})[tag]||tag):document.createDocumentFragment();
   if(el.nodeType===1){
    if(/^(left|center|right|justify)$/.test(node.style.textAlign))el.style.textAlign=node.style.textAlign;
    if(tag==='a'&&/^(https?:\/\/|\/(?!\/)|#)/i.test(node.getAttribute('href')||''))el.setAttribute('href',node.getAttribute('href'));
    if(tag==='img'){
     if(!/^(https:\/\/|\/uploads\/)/i.test(node.getAttribute('src')||''))return document.createDocumentFragment();
     el.setAttribute('src',node.getAttribute('src'));el.setAttribute('alt',node.getAttribute('alt')||'');
    }
   }
   node.childNodes.forEach(n=>el.append(visit(n)));
   if(el.nodeType===1){
    const wrappers=[];
    if(node.style.fontWeight==='bold'||Number(node.style.fontWeight)>=600)wrappers.push('strong');
    if(node.style.fontStyle==='italic')wrappers.push('em');
    if(node.style.textDecorationLine.includes('underline'))wrappers.push('u');
    if(node.style.textDecorationLine.includes('line-through'))wrappers.push('s');
    wrappers.forEach(tag=>{const wrapper=document.createElement(tag);while(el.firstChild)wrapper.append(el.firstChild);el.append(wrapper)});
   }
   return el;
  };
  const result=document.createElement('div');doc.body.childNodes.forEach(n=>result.append(visit(n)));return result.innerHTML;
 };
 document.querySelectorAll('[data-le-editor]').forEach(box=>{
  if(box.parentElement.tagName==='LABEL'){
   const label=box.parentElement,field=document.createElement('div');field.className=label.className;
   while(label.firstChild)field.append(label.firstChild);label.replaceWith(field);
  }
  const text=box.querySelector('textarea'),format=box.closest('form')?.querySelector('[name="content_format"]'),basic=box.dataset.leEditor==='basic';
  if(!text)return;
  text.setAttribute('aria-label',basic?(text.name==='bio'?leT("O mnie"):leT("Podpis / sygnatura")):leT("Treść — kod"));
  let source=basic||format?.value==='markdown',range=null;
  const visual=document.createElement('div');visual.className='visual-editor';visual.contentEditable='true';visual.setAttribute('role','textbox');visual.setAttribute('aria-multiline','true');visual.setAttribute('aria-label',leT("Treść — edytor wizualny"));text.after(visual);
  const sync=()=>{if(!source)text.value=clean(visual.innerHTML);text.dispatchEvent(new Event('input',{bubbles:true}))};
  text.leEditorLoad=value=>{text.value=value;show();};
   const show=()=>{visual.hidden=source;text.hidden=!source;if(!source)visual.innerHTML=clean(text.value);box.querySelectorAll('[data-editor-cmd]').forEach(b=>{b.disabled=!basic&&source&&(format?.value==='markdown'?!['bold','italic','h2','h3','insertUnorderedList','link','code'].includes(b.dataset.editorCmd):['removeFormat','undo','redo'].includes(b.dataset.editorCmd))})};
  visual.addEventListener('input',sync);
  visual.addEventListener('paste',event=>{event.preventDefault();document.execCommand('insertText',false,event.clipboardData.getData('text/plain'));sync()});
  const saveRange=()=>{const s=getSelection();if(s?.rangeCount&&visual.contains(s.anchorNode))range=s.getRangeAt(0).cloneRange()};
  visual.addEventListener('keyup',saveRange);visual.addEventListener('mouseup',saveRange);visual.addEventListener('focusout',saveRange);
  const restore=()=>{visual.focus();if(range&&visual.contains(range.startContainer)){const s=getSelection();s.removeAllRanges();s.addRange(range)}};
  const put=value=>{if(source){const next=text.value.length-(text.selectionEnd-text.selectionStart)+value.length;if(text.maxLength>0&&next>text.maxLength){alert(leT("Przekroczono limit znaków."));return}text.setRangeText(value,text.selectionStart,text.selectionEnd,'end');text.dispatchEvent(new Event('input',{bubbles:true}));text.focus()}else{restore();document.execCommand('insertHTML',false,clean(value));sync();saveRange()}};
  text.leEditorInsert=put;text.leEditorRemember=saveRange;
  box.querySelector('[data-editor-source]')?.addEventListener('click',()=>{if(format?.value==='markdown')return;sync();source=!source;show()});
  format?.addEventListener('change',()=>{sync();source=format.value==='markdown';show()});
  box.querySelectorAll('[data-editor-cmd]').forEach(button=>{
   button.addEventListener('mousedown',e=>e.preventDefault());
   button.addEventListener('click',()=>{
    const cmd=button.dataset.editorCmd;
    if(source){
     const selected=text.value.slice(text.selectionStart,text.selectionEnd)||leT("tekst");let wrap;
     if(basic){const tag={bold:'b',italic:'i',underline:'u',strikeThrough:'s',justifyLeft:'left',justifyCenter:'center',justifyRight:'right'}[cmd];if(tag)wrap=['['+tag+']','[/'+tag+']']}
     else if(format?.value==='markdown')wrap={bold:['**','**'],italic:['*','*'],h2:['## ',''],h3:['### ',''],insertUnorderedList:['- ',''],code:['`','`']}[cmd];
     else {const tag={bold:'strong',italic:'em',underline:'u',strikeThrough:'s',h2:'h2',h3:'h3',p:'p',blockquote:'blockquote',code:'code'}[cmd];if(tag)wrap=['<'+tag+'>','</'+tag+'>'];if(cmd.startsWith('justify'))wrap=['<p style="text-align:'+({justifyLeft:'left',justifyCenter:'center',justifyRight:'right',justifyFull:'justify'})[cmd]+'">','</p>'];if(cmd==='insertUnorderedList'||cmd==='insertOrderedList'){const tag=cmd==='insertOrderedList'?'ol':'ul';wrap=['<'+tag+'><li>','</li></'+tag+'>']}}
     if(cmd==='link'){const url=prompt(leT("Adres linku:"),'https://');if(!url||!/^https?:\/\//i.test(url))return;put(format?.value==='markdown'?'['+selected+']('+url.replace(/[\s)]/g,'')+')':'<a href="'+url.replace(/["<>]/g,'')+'">'+selected+'</a>')}
     else if(wrap)put(wrap[0]+selected+wrap[1]);return;
    }
    restore();if(cmd==='link'){const url=prompt('Adres linku:','https://');if(url&&/^https?:\/\//i.test(url))document.execCommand('createLink',false,url)}
    else if(['h2','h3','p','blockquote','code'].includes(cmd))document.execCommand('formatBlock',false,cmd==='code'?'pre':cmd);
    else document.execCommand(cmd,false,null);sync();saveRange();
   });
  });
  text.closest('form')?.addEventListener('submit',sync);show();
 });
 document.querySelectorAll('textarea').forEach(text=>{
  const counter=document.createElement('small');counter.className='editor-counter';text.after(counter);
  const update=()=>{const length=Array.from(text.value).length;counter.textContent=length+' znaków'+(text.maxLength>0?' / '+text.maxLength:'');counter.classList.toggle('over-limit',text.maxLength>0&&length>text.maxLength)};text.addEventListener('input',update);update();
  if(text.name==='css'){text.spellcheck=false;text.addEventListener('keydown',event=>{if(event.key==='Tab'){event.preventDefault();text.setRangeText('    ',text.selectionStart,text.selectionEnd,'end');text.dispatchEvent(new Event('input',{bubbles:true}))}})}
 });
})();
