window.leT??=(text)=>text;
(()=>{
 const links=[...document.querySelectorAll('[data-gallery-item]')];if(!links.length)return;
 const dialog=document.createElement('dialog');dialog.className='gallery-lightbox';dialog.setAttribute('aria-label',leT('Podgląd zdjęcia'));
 if(typeof dialog.showModal!=='function')return;
 const image=document.createElement('img'),caption=document.createElement('p'),controls=document.createElement('div');
 const button=(label,action)=>{const b=document.createElement('button');b.type='button';b.className='btn';b.textContent=leT(label);b.addEventListener('click',action);return b};
 let index=0,trigger=null;
 const show=position=>{index=(position+links.length)%links.length;const link=links[index],thumb=link.querySelector('img');image.src=link.href;image.alt=thumb?.alt||'';caption.textContent=(thumb?.alt||'')+' ('+(index+1)+' / '+links.length+')'};
 const close=()=>{dialog.close();trigger?.focus()};
 const previous=button('Poprzednie zdjęcie',()=>show(index-1)),next=button('Następne zdjęcie',()=>show(index+1)),exit=button('Zamknij podgląd',close);
 previous.hidden=next.hidden=links.length<2;controls.append(previous,next,exit);dialog.append(controls,image,caption);document.body.append(dialog);
 links.forEach((link,i)=>link.addEventListener('click',e=>{if(e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;e.preventDefault();trigger=link;show(i);dialog.showModal();exit.focus()}));
 dialog.addEventListener('cancel',event=>{event.preventDefault();close()});
 dialog.addEventListener('keydown',event=>{if(event.key==='ArrowRight'){event.preventDefault();show(index+1)}if(event.key==='ArrowLeft'){event.preventDefault();show(index-1)}});
 dialog.addEventListener('click',event=>{if(event.target===dialog){const rect=dialog.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)close()}});
})();
