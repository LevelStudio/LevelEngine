(() => {
  'use strict';
  const boot = JSON.parse(document.getElementById('studio-boot').textContent);
  const t = text => boot.messages?.[text] ?? text;
  let doc = structuredClone(boot.document), design = {...boot.design}, selected = doc.blocks[0]?.id;
  const builder = document.getElementById('builder-form'), designForm = document.getElementById('design-form');
  const frame = document.getElementById('studio-preview'), status = document.getElementById('preview-status');
  const content = document.getElementById('block-content'), list = document.getElementById('block-list'), editor = document.getElementById('block-editor');
  const csrf = document.querySelector('#preview-token input');
  let previewTimer, controller, serial = 0, changed = false, submitting = false, draftTimer, draftSaving=false, draftDirty=false;
  const history = [], future = [];
  const el = (tag, text, cls) => {const n = document.createElement(tag); if(text !== undefined)n.textContent = t(text); if(cls)n.className = cls; return n;};
  const uid = () => crypto.randomUUID().replaceAll('-', '');
  const url = new URL(location.href);
  if(builder && !builder.elements.id.value.replace(/^0$/, '') && !url.searchParams.has('draft')){url.searchParams.set('draft', uid());window.history.replaceState(null, '', url);}
  const draftKey = builder ? `levelengine-studio:${boot.user}:${builder.elements.id.value === '0' ? url.searchParams.get('draft') : builder.elements.id.value}` : '';
  if(builder && url.searchParams.get('saved') === '1'){try{localStorage.removeItem(draftKey);}catch{}url.searchParams.delete('saved');window.history.replaceState(null, '', url);}
  function localSave(){
    if(!builder)return;
    const fields={};for(const key of ['title','slug','status','publish_at','menu_order','seo_title','seo_description','edit_version'])fields[key]=builder.elements[key].value;
    fields.show_in_menu=builder.elements.show_in_menu.checked;
    try{localStorage.setItem(draftKey,JSON.stringify({doc,fields,at:Date.now()}));document.getElementById('draft-status').textContent='Lokalna kopia: '+new Date().toLocaleTimeString();}
    catch{document.getElementById('draft-status').textContent=t('Nie udało się zapisać kopii w tej przeglądarce.');}
  }
  function snapshot(){history.push(JSON.stringify(doc));if(history.length>50)history.shift();future.length=0;}
  function touch(){changed=true;if(content)content.value=JSON.stringify(doc);localSave();scheduleDraft();queuePreview();updateHistory();quality();}
  function updateHistory(){if(!builder)return;document.getElementById('undo').disabled=!history.length;document.getElementById('redo').disabled=!future.length;}
  function queuePreview(){clearTimeout(previewTimer);previewTimer=setTimeout(preview,350);}
  async function preview(){
    const request=++serial;if(controller)controller.abort();controller=new AbortController();status.textContent=t('Odświeżanie…');
    try{
      const data=new FormData();data.set(csrf.name,csrf.value);data.set('action','preview');data.set('content',JSON.stringify(doc));data.set('design',JSON.stringify(design));
      const res=await fetch('/admin/studio.php'+(designForm?'?view=design':''),{method:'POST',body:data,signal:controller.signal});const json=await res.json();
      if(!res.ok||!json.ok)throw new Error(json.error||'Nie udało się odświeżyć podglądu.');
      if(request===serial){frame.srcdoc=json.html;status.textContent=t('Podgląd aktualny');}
    }catch(e){if(e.name!=='AbortError'&&request===serial)status.textContent=e.message;}
  }
  document.querySelectorAll('[data-device]').forEach(b=>b.addEventListener('click',()=>{frame.classList.toggle('mobile',b.dataset.device==='mobile');frame.classList.toggle('tablet',b.dataset.device==='tablet');document.querySelectorAll('[data-device]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));}));
  document.querySelectorAll('[data-kit-preview]').forEach(b=>b.addEventListener('click',()=>{doc=structuredClone(boot.kits[b.dataset.kitPreview]);queuePreview();frame.scrollIntoView({behavior:'smooth',block:'center'});}));
  function scheduleDraft(){if(!builder||submitting)return;draftDirty=true;clearTimeout(draftTimer);draftTimer=setTimeout(saveDraft,4000);}
  async function saveDraft(){
    if(!builder||submitting||draftSaving||!draftDirty)return;if(builder.elements.id.value==='0'){document.getElementById('server-draft-status').textContent=t('Kopia na serwerze będzie dostępna po pierwszym zapisie strony.');return;}draftDirty=false;draftSaving=true;
    const status=document.getElementById('server-draft-status');
    try{const data=new FormData(builder);data.set('action','suite_autosave');data.set('show_in_menu',builder.elements.show_in_menu.checked?'1':'0');const response=await fetch('/admin/suite-api.php',{method:'POST',body:data});const json=await response.json();if(!response.ok||!json.ok)throw new Error(json.error||t('Błąd zapisu'));status.textContent=t('Kopia na serwerze:')+' '+new Date().toLocaleTimeString();}
    catch(error){status.textContent=t('Kopia na serwerze niezapisana:')+' '+error.message;}
    finally{draftSaving=false;if(draftDirty&&!submitting)draftTimer=setTimeout(saveDraft,4000);}
  }
  async function restoreDraft(document,fields){
    const baseline=JSON.stringify(doc);const data=new FormData();data.set(csrf.name,csrf.value);data.set('action','preview');data.set('content',JSON.stringify(document));data.set('design',JSON.stringify(design));
    const response=await fetch('/admin/studio.php',{method:'POST',body:data}),json=await response.json();if(!response.ok||!json.ok||!json.document)throw new Error(json.error||t('Nieprawidłowa kopia robocza.'));
    if(JSON.stringify(doc)!==baseline)throw new Error(t('Układ zmienił się podczas odzyskiwania. Spróbuj ponownie.'));
    if(!confirm(t('Zastąpić układ i pola formularza kopią roboczą?'))){return;}
    snapshot();doc=json.document;
    for(const key of ['title','slug','status','publish_at','menu_order','seo_title','seo_description','edit_version'])if(typeof fields[key]==='string'||typeof fields[key]==='number')builder.elements[key].value=fields[key];
    if('show_in_menu' in fields)builder.elements.show_in_menu.checked=[true,1,'1'].includes(fields.show_in_menu);
    selected=doc.blocks[0]?.id;renderList();renderEditor();touch();
  }
  function quality(){
    const list=document.getElementById('studio-quality-list');if(!builder||!list)return;list.replaceChildren();const notes=[];
    const visible=doc.blocks.filter(block=>!block.hidden);
    if(!visible.length)notes.push('Dodaj przynajmniej jedną widoczną sekcję.');
    if(visible.filter(block=>block.type==='hero').length!==1)notes.push('Użyj jednego banera głównego jako nagłówka H1.');
    if(!builder.elements.seo_description.value.trim())notes.push('Dodaj opis SEO, aby opisać stronę w wyszukiwarce.');
    let alt=0,buttons=0,anchors=0;const available=new Set(visible.map(block=>block.anchor||'block-'+block.id));
    for(const block of visible){if(block.image&&!block.alt)alt++;if(Boolean(block.button)!==Boolean(block.url))buttons++;for(const item of block.items||[])if(item.image&&!item.alt)alt++;for(const url of [block.url,...(block.items||[]).map(item=>item.url)])if(url?.startsWith('#')&&url.length>1&&!available.has(url.slice(1)))anchors++;}
    if(alt)notes.push(t('Obrazy bez opisu ALT:')+' '+alt);
    if(buttons)notes.push('Uzupełnij tekst i adres przycisków.');
    if(anchors)notes.push('Sprawdź linki do kotwic: część sekcji jest ukryta lub nie istnieje.');
    if(builder.elements.status.value==='scheduled'&&!builder.elements.publish_at.value)notes.push('Wybierz termin zaplanowanej publikacji.');
    document.getElementById('quality-count').textContent=notes.length?String(notes.length):'✓';
    if(!notes.length)list.append(el('li','Podstawowe elementy są gotowe. Sprawdź jeszcze treść i widok telefonu.','quality-ok'));
    else notes.forEach(note=>list.append(el('li',note)));
  }
  document.querySelectorAll('[data-preview-expand]').forEach(button=>button.addEventListener('click',()=>{const canvas=frame.closest('.studio-canvas')||frame.parentElement;const open=canvas.classList.toggle('preview-expanded');button.setAttribute('aria-pressed',String(open));button.textContent=open?'↙':'⤢';}));
  document.addEventListener('keydown',event=>{if(event.key==='Escape')document.querySelector('.preview-expanded')?.classList.remove('preview-expanded');});
  function newBlock(type){
    const b={id:uid(),type,title:boot.types[type],text:'Dodaj własny tekst.',eyebrow:'',button:'',url:'',image:'',alt:'',tone:'plain',align:'left',anchor:'',spacing:'normal',columns:'auto',hidden:false,items:[]};
    if(type==='hero'){b.title='Tu zaczyna się Twoja historia.';b.eyebrow='POZNAJ NAS';b.tone='accent';b.button='Dowiedz się więcej';b.url='/news/';}
    if(['features','pricing','team','testimonials','faq','gallery','stats','timeline','logos','contact'].includes(type))b.items=Array.from({length:type==='faq'?2:3},(_,i)=>({title:type==='faq'?`Pytanie ${i+1}`:`Element ${i+1}`,text:'Opis, który możesz zmienić.',meta:type==='pricing'?'99 zł / mies.':'',image:'',alt:'',url:''}));
    if(type==='contact'){b.title='Porozmawiajmy';b.text='Wybierz wygodny sposób kontaktu.';b.items=[{title:'Napisz do nas',text:'Odpowiemy na Twoje pytania.',meta:'E-MAIL',url:'mailto:kontakt@example.com',image:'',alt:''},{title:'Zadzwoń',text:'Wpisz własny numer telefonu.',meta:'TELEFON',url:'tel:+48123456789',image:'',alt:''}];}if(type==='stats')b.items.forEach((x,i)=>{x.title=['10+','24/7','100%'][i];x.text=['Lat doświadczenia','Dostępność informacji','Zaangażowania'][i];});if(type==='timeline')b.items.forEach((x,i)=>{x.meta=String(i+1).padStart(2,'0');x.title=['Rozmowa','Realizacja','Wdrożenie'][i];});if(type==='logos')b.items.forEach((x,i)=>{x.title='Partner '+(i+1);x.text='';});if(type==='posts')b.text='';return b;
  }
  function move(from,to){if(from===to||to<0||to>=doc.blocks.length)return;snapshot();const [b]=doc.blocks.splice(from,1);doc.blocks.splice(to,0,b);renderList();touch();}
  function renderList(){
    if(!list)return;list.replaceChildren();document.getElementById('block-count').textContent=`${doc.blocks.length}/60`;
    doc.blocks.forEach((b,i)=>{
      const row=el('div',undefined,'block-row'+(selected===b.id?' active':''));row.draggable=true;row.dataset.id=b.id;
      row.append(el('span','⠿','drag-grip'));
      const pick=el('button',(b.hidden?'◌ ':'')+(b.title||boot.types[b.type]));pick.type='button';pick.setAttribute('aria-label',`Edytuj blok ${i+1}: ${b.title||boot.types[b.type]}`);pick.addEventListener('click',()=>{selected=b.id;renderList();renderEditor();});row.append(pick);
      for(const [label,delta] of [['↑',-1],['↓',1]]){const btn=el('button',label,'mini');btn.type='button';btn.disabled=i+delta<0||i+delta>=doc.blocks.length;btn.setAttribute('aria-label',label==='↑'?'Przesuń blok wyżej':'Przesuń blok niżej');btn.addEventListener('click',()=>move(i,i+delta));row.append(btn);}
      row.addEventListener('dragstart',e=>{e.dataTransfer.setData('text/plain',b.id);e.dataTransfer.effectAllowed='move';});row.addEventListener('dragover',e=>e.preventDefault());row.addEventListener('drop',e=>{e.preventDefault();const from=doc.blocks.findIndex(x=>x.id===e.dataTransfer.getData('text/plain'));if(from>=0)move(from,i);});list.append(row);
    });
    if(!doc.blocks.length)list.append(el('p','Dodaj pierwszy blok, aby zacząć.','muted'));
  }
  async function mediaPicker(target,refresh){
    const dialog=el('dialog',undefined,'studio-media'), heading=el('h2','Biblioteka obrazów'), close=el('button','Zamknij'), search=el('input'), results=el('div',undefined,'media-results'), note=el('p','Ładowanie…');
    search.placeholder='Szukaj obrazów…';search.setAttribute('aria-label','Szukaj obrazów');close.type='button';close.onclick=()=>dialog.close();dialog.append(heading,close,search,note,results);document.body.append(dialog);dialog.addEventListener('close',()=>dialog.remove());dialog.showModal();
    let offset=0, term='', loading=false;
    async function load(reset=false){if(loading)return;loading=true;if(reset){offset=0;results.replaceChildren();}try{const res=await fetch('/admin/media-api.php?q='+encodeURIComponent(term)+'&offset='+offset);const json=await res.json();if(!res.ok||!json.ok)throw new Error(json.error||'Błąd biblioteki');note.textContent=t('Wybierz obraz.');for(const item of json.items||[]){const btn=el('button'),img=el('img');btn.type='button';img.src=item.path;img.alt=item.alt_text||item.title||'';btn.append(img,el('span',item.title||'Obraz'));btn.onclick=()=>{snapshot();target.image=item.path;if(!target.alt)target.alt=item.alt_text||'';touch();refresh();dialog.close();};results.append(btn);}offset=json.next_offset??offset+(json.items||[]).length;more.hidden=!json.has_more;if(!(json.items||[]).length)note.textContent='Nie znaleziono obrazów. Dodaj obraz lub zmień wyszukiwanie.';}catch(e){note.textContent=e.message;}finally{loading=false;}}
    const upload=el('input');upload.type='file';upload.accept='image/jpeg,image/png,image/webp,image/gif';upload.setAttribute('aria-label','Wgraj nowy obraz');upload.addEventListener('change',async()=>{if(!upload.files[0])return;note.textContent=t('Wgrywanie…');try{const data=new FormData();data.set(csrf.name,csrf.value);data.set('image',upload.files[0]);const res=await fetch('/admin/media-api.php',{method:'POST',body:data}),json=await res.json();if(!res.ok||!json.ok)throw new Error(json.error||'Błąd wgrywania');snapshot();target.image=json.item.path;touch();refresh();dialog.close();}catch(e){note.textContent=e.message;}});dialog.append(upload);
    const more=el('button','Pokaż więcej');more.type='button';more.onclick=()=>load();dialog.append(more);let searchTimer;search.oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>{term=search.value;load(true);},350);};await load();
  }
  function field(parent,obj,key,label,kind='input',options){
    const wrap=el('label',t(label));const input=el(options?'select':kind);if(options)for(const [value,text] of Object.entries(options)){const op=el('option',text);op.value=value;input.append(op);}input.value=obj[key]??'';if(kind!=='textarea'&&!options)input.type='text';
    if(key==='text'||key==='title')wrap.classList.add('full');input.maxLength=key==='text'?(doc.blocks.includes(obj)?20000:5000):key==='anchor'?64:['url','image'].includes(key)?2048:300;
    let recorded=false;input.addEventListener('focus',()=>recorded=false);input.addEventListener('input',()=>{if(!recorded){snapshot();recorded=true;}obj[key]=input.value;if(key==='title')renderList();touch();});wrap.append(input);
    if(key==='image'&&boot.media){const btn=el('button','Wybierz / wgraj obraz');btn.type='button';btn.onclick=()=>mediaPicker(obj,renderEditor);wrap.append(btn);}
    parent.append(wrap);
  }
  function renderEditor(){
    if(!editor)return;editor.replaceChildren();const b=doc.blocks.find(x=>x.id===selected);if(!b){editor.append(el('p','Wybierz blok z listy albo dodaj nowy.','muted'));return;}
    editor.append(el('h2',boot.types[b.type]));const actions=el('div',undefined,'block-actions');
    const duplicate=el('button','Duplikuj blok');duplicate.type='button';duplicate.onclick=()=>{if(doc.blocks.length>=60)return;snapshot();const copy=structuredClone(b);copy.id=uid();copy.anchor="";doc.blocks.splice(doc.blocks.indexOf(b)+1,0,copy);selected=copy.id;renderList();renderEditor();touch();};
    const remove=el('button','Usuń blok');remove.type='button';remove.onclick=()=>{snapshot();const at=doc.blocks.indexOf(b);doc.blocks.splice(at,1);selected=doc.blocks[Math.min(at,doc.blocks.length-1)]?.id;renderList();renderEditor();touch();};const visibility=el('button',b.hidden?'Pokaż sekcję':'Ukryj sekcję');visibility.type='button';visibility.setAttribute('aria-pressed',String(!!b.hidden));visibility.onclick=()=>{snapshot();b.hidden=!b.hidden;renderList();renderEditor();touch();};actions.append(visibility,duplicate,remove);editor.append(actions);
    const fields=el('div',undefined,'field-grid');field(fields,b,'eyebrow','Mały nagłówek');field(fields,b,'tone','Tło sekcji','select',{plain:'Podstawowe',soft:'Wyróżnione',accent:'Poświata akcentu'});field(fields,b,'title','Nagłówek');field(fields,b,'text','Opis','textarea');field(fields,b,'align','Wyrównanie','select',{left:'Do lewej',center:'Na środku'});field(fields,b,'button','Tekst przycisku');field(fields,b,'url','Adres przycisku');field(fields,b,'image','Obraz sekcji — adres');field(fields,b,'alt','Opis obrazu');field(fields,b,'anchor','Kotwica sekcji (np. oferta)');field(fields,b,'spacing','Odstępy sekcji','select',{compact:'Małe',normal:'Standardowe',spacious:'Duże'});field(fields,b,'columns','Kolumny na komputerze','select',{auto:'Automatycznie',1:'Jedna',2:'Dwie',3:'Trzy',4:'Cztery'});editor.append(fields);
    if(['features','pricing','team','testimonials','faq','gallery','stats','timeline','logos','contact'].includes(b.type)){
      editor.append(el('h2','Elementy sekcji'));
      b.items.forEach((item,i)=>{const box=el('div',undefined,'item-editor'),head=el('div',undefined,'item-heading');head.append(el('strong',`Element ${i+1}`));const controls=el('div');for(const [text,fn] of [['↑',()=>{if(i){snapshot();[b.items[i-1],b.items[i]]=[b.items[i],b.items[i-1]];renderEditor();touch();}}],['Usuń',()=>{snapshot();b.items.splice(i,1);renderEditor();touch();}]]){const btn=el('button',text);btn.type='button';btn.onclick=fn;controls.append(btn);}head.append(controls);box.append(head);const grid=el('div',undefined,'field-grid');field(grid,item,'title',b.type==='faq'?'Pytanie':'Tytuł / imię');field(grid,item,'text',b.type==='faq'?'Odpowiedź':'Opis','textarea');if(b.type!=='faq'){field(grid,item,'meta','Cena / stanowisko / podpis');field(grid,item,'url','Adres odnośnika');field(grid,item,'image','Obraz — adres');field(grid,item,'alt','Opis obrazu');}box.append(grid);editor.append(box);});
      const add=el('button','+ Dodaj element');add.type='button';add.disabled=b.items.length>=24;add.onclick=()=>{snapshot();b.items.push({title:'Nowy element',text:'',meta:'',image:'',alt:'',url:''});renderEditor();touch();};editor.append(add);
    }
  }
  if(builder){
    document.getElementById('layout-export').onclick=()=>{
      const data={format:'levelengine-layout',version:1,creator:'LevelGame.pl',document:doc};
      const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download='levelengine-layout.json';link.click();setTimeout(()=>URL.revokeObjectURL(link.href),1000);
    };
    const importFile=document.getElementById('layout-import'),importStatus=document.getElementById('layout-status');
    let importing=false;
    importFile.onchange=async()=>{
      const file=importFile.files[0];if(!file||importing)return;
      const baseline=JSON.stringify(doc);importing=true;importFile.disabled=true;
      try{
        if(file.size>1500000)throw new Error(t('Układ przekracza 1,5 MB.'));
        const raw=JSON.parse(await file.text());if(raw.format!=='levelengine-layout'||raw.version!==1||!raw.document)throw new Error(t('Nieprawidłowy plik układu.'));
        const data=new FormData();data.set(csrf.name,csrf.value);data.set('action','layout_import');data.set('layout',JSON.stringify(raw));data.set('design',JSON.stringify(design));
        const res=await fetch('/admin/studio.php',{method:'POST',body:data}),json=await res.json();
        if(!res.ok||!json.ok||!json.document)throw new Error(json.error||t('Nieprawidłowy plik układu.'));
        if(JSON.stringify(doc)!==baseline)throw new Error(t('Układ zmienił się podczas importu. Spróbuj ponownie.'));
        if(!confirm(t('Zastąpić obecny układ? Możesz cofnąć tę operację.')))return;
        snapshot();doc=json.document;selected=doc.blocks[0]?.id;renderList();renderEditor();touch();importStatus.textContent=t('Układ zaimportowany. Zapisz stronę, aby zachować zmiany.');
      }catch(e){importStatus.textContent=e.message;}finally{importing=false;importFile.disabled=false;importFile.value='';}
    };
    document.addEventListener('keydown',e=>{if(!(e.ctrlKey||e.metaKey)||e.altKey)return;const key=e.key.toLowerCase();if(key==='s'){e.preventDefault();builder.requestSubmit();}else if(key==='z'&&!e.target.closest('input,textarea,select,[contenteditable]')){e.preventDefault();document.getElementById(e.shiftKey?'redo':'undo').click();}});
    document.getElementById('block-add').onclick=()=>{if(doc.blocks.length>=60)return;snapshot();const b=newBlock(document.getElementById('block-type').value);doc.blocks.push(b);selected=b.id;renderList();renderEditor();touch();};
    document.getElementById('undo').onclick=()=>{if(!history.length)return;future.push(JSON.stringify(doc));doc=JSON.parse(history.pop());selected=doc.blocks.some(b=>b.id===selected)?selected:doc.blocks[0]?.id;renderList();renderEditor();touch();};
    document.getElementById('redo').onclick=()=>{if(!future.length)return;history.push(JSON.stringify(doc));doc=JSON.parse(future.pop());selected=doc.blocks[0]?.id;renderList();renderEditor();touch();};
    builder.addEventListener('input',e=>{if(e.target.name&&e.target.name!=='content'){changed=true;localSave();scheduleDraft();quality();}});builder.addEventListener('change',e=>{if(e.target.name){changed=true;localSave();scheduleDraft();quality();}});
    builder.addEventListener('submit',()=>{submitting=true;clearTimeout(draftTimer);content.value=JSON.stringify(doc);localSave();});
    document.getElementById('recover-draft').onclick=async()=>{
      try{const saved=JSON.parse(localStorage.getItem(draftKey)||'null');if(!saved){document.getElementById('draft-status').textContent=t('Brak lokalnej kopii.');return;}await restoreDraft(saved.doc,saved.fields||{});}
      catch(error){document.getElementById('draft-status').textContent=error.message||t('Nie można odczytać lokalnej kopii.');}
    };
    if(builder.elements.id.value==='0')document.getElementById('recover-server-draft').disabled=true;
    document.getElementById('recover-server-draft').onclick=async()=>{
      const status=document.getElementById('server-draft-status');
      try{const response=await fetch('/admin/suite-api.php?kind=page&id='+encodeURIComponent(builder.elements.id.value));const json=await response.json();if(!response.ok||!json.ok||!json.snapshot)throw new Error(t('Brak kopii roboczej na serwerze.'));await restoreDraft(JSON.parse(json.snapshot.content),json.snapshot);status.textContent=t('Kopia odzyskana. Sprawdź treść i zapisz.');}
      catch(error){status.textContent=error.message;}
    };
    try{const saved=JSON.parse(localStorage.getItem(draftKey)||'null');if(saved?.doc&&JSON.stringify(saved.doc)!==JSON.stringify(doc))document.getElementById('draft-status').textContent=t('Znaleziono lokalny szkic:')+' '+new Date(saved.at).toLocaleString();}catch{}
    document.getElementById('page-picker').onchange=e=>{if(changed&&!confirm(t('Opuścić stronę bez zapisu na serwerze? Lokalny szkic pozostanie w tej przeglądarce.'))){e.target.value=builder.elements.id.value==='0'?'':builder.elements.id.value;return;}location.href='/admin/studio.php'+(e.target.value?'?id='+encodeURIComponent(e.target.value):'');};
    renderList();renderEditor();updateHistory();quality();
  }
  if(designForm){
    const read=()=>{for(const key of Object.keys(design))design[key]=designForm.elements[key].value;changed=true;queuePreview();};designForm.addEventListener('input',read);designForm.addEventListener('change',read);designForm.addEventListener('submit',()=>submitting=true);
    const builtins={'@midnight':{accent:'#7c5cff',background:'#10121a',surface:'#1a1d29',text:'#f4f5fb',muted:'#b1b7cc',font:'modern',width:'normal',radius:'soft'},'@paper':{accent:'#855a36',background:'#faf7f0',surface:'#ffffff',text:'#28251f',muted:'#716b60',font:'editorial',width:'compact',radius:'square'},'@forest':{accent:'#27845c',background:'#eef5ef',surface:'#ffffff',text:'#183528',muted:'#536c5b',font:'system',width:'wide',radius:'round'}};
    document.getElementById('design-presets').onchange=e=>{const d=builtins[e.target.value]||boot.presets[e.target.value];if(!d)return;design={...d};for(const [k,v] of Object.entries(d))designForm.elements[k].value=v;if(!e.target.value.startsWith('@'))designForm.elements.preset_name.value=e.target.value;read();};
  }
  window.addEventListener('beforeunload',e=>{if(changed&&!submitting){e.preventDefault();e.returnValue='';}});
  queuePreview();
})();
