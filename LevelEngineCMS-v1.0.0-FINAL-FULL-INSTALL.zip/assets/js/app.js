window.leT??=(text)=>text;
document.querySelectorAll('[data-copy]').forEach(btn=>btn.addEventListener('click',async()=>{
  const text=btn.dataset.copy||'', old=btn.textContent;
  try {
    if(navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
    else {
      const field=document.createElement('textarea');field.value=text;field.style.position='fixed';field.style.opacity='0';document.body.appendChild(field);field.select();
      let copied;try{copied=document.execCommand('copy')}finally{field.remove()}
      if(!copied)throw new Error('clipboard');
    }
    btn.textContent=leT("Skopiowano ✓");
  } catch(e) { window.prompt(leT("Skopiuj adres serwera:"),text);btn.textContent=leT("Skopiuj adres"); }
  setTimeout(()=>btn.textContent=old,1400);
}));

// Public response contains only visible server statuses, never bridge keys.
(()=>{
  const cards=[...document.querySelectorAll('[data-server-id]')];if(!cards.length)return;
  let pending=false;
  const refresh=async()=>{
    if(pending||document.hidden)return;pending=true;
    try{
      const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),8000);
      let response;try{response=await fetch('/server-status.php',{cache:'no-store',signal:controller.signal})}finally{clearTimeout(timeout)}
      if(!response.ok)return;const data=await response.json();if(!data.ok||!Array.isArray(data.servers))return;
      const statuses=new Map(data.servers.map(s=>[String(s.id),s]));
      cards.forEach(card=>{
        const s=statuses.get(card.dataset.serverId);
        if(!s){card.hidden=true;return}card.hidden=false;
        const status=card.querySelector('[data-server-status]');
        if(status){const state=['online','offline','unknown'].includes(s.status)?s.status:'unknown';status.className='server-status '+state;status.replaceChildren(document.createElement('i'),document.createTextNode(leT(s.status_label||state.toUpperCase())))}
        const count=card.querySelector('[data-server-players]');if(count)count.textContent=String(s.players)+(s.max_players>0?' / '+s.max_players:'');
        const version=card.querySelector('[data-server-version]');if(version)version.textContent=s.version||'';
        const wrap=card.querySelector('[data-server-version-wrap]');if(wrap)wrap.hidden=!s.version;
      });
    }catch(e){}finally{pending=false}
  };
  refresh();setInterval(refresh,15000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh()});
})();


// LevelEngine CMS v1.3 — mobile navigation
(()=>{const toggle=document.querySelector('.mobile-menu-toggle');const menu=document.getElementById('mobile-nav');if(!toggle||!menu)return;const close=()=>{toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-label',leT("Otwórz menu"));menu.hidden=true;document.body.classList.remove('mobile-menu-open')};toggle.addEventListener('click',()=>{const open=toggle.getAttribute('aria-expanded')==='true';if(open){close()}else{toggle.setAttribute('aria-expanded','true');toggle.setAttribute('aria-label',leT("Zamknij menu"));menu.hidden=false;document.body.classList.add('mobile-menu-open')}});menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',close));window.addEventListener('resize',()=>{if(window.innerWidth>900)close()});document.addEventListener('keydown',e=>{if(e.key==='Escape')close()})})();
