window.leT??=(text)=>text;
(function(){
 document.querySelectorAll('.copy-media').forEach(b=>b.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(b.dataset.copy||'');const old=b.textContent;b.textContent=leT("Skopiowano ✓");setTimeout(()=>b.textContent=old,1200)}catch(e){}}));
})();

// Responsive navigation with keyboard focus management.
(()=>{
 const btn=document.querySelector('.admin-menu-toggle'),overlay=document.querySelector('[data-admin-overlay]'),sidebar=document.querySelector('#admin-sidebar');if(!btn||!sidebar)return;
 const mobile=()=>innerWidth<=760;
 const set=(open,restore=false)=>{open=mobile()&&open;document.body.classList.toggle('admin-menu-open',open);btn.setAttribute('aria-expanded',String(open));btn.setAttribute('aria-label',leT(open?'Zamknij menu':'Otwórz menu'));sidebar.inert=mobile()&&!open;sidebar.setAttribute('aria-hidden',String(mobile()&&!open));if(open)sidebar.querySelector('[data-command-open],a,button')?.focus();else if(restore&&mobile())btn.focus();};
 btn.addEventListener('click',()=>set(!document.body.classList.contains('admin-menu-open'),true));overlay?.addEventListener('click',()=>set(false,true));sidebar.querySelector('[data-admin-close]')?.addEventListener('click',()=>set(false,true));
 sidebar.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{if(mobile())set(false)}));
 addEventListener('keydown',event=>{if(!mobile()||!document.body.classList.contains('admin-menu-open'))return;if(event.key==='Escape'){set(false,true);return;}if(event.key==='Tab'&&!document.querySelector('dialog[open]')){const items=[...sidebar.querySelectorAll('a,button,input,[tabindex="0"]')].filter(x=>!x.disabled&&x.offsetParent!==null),first=items[0],last=items.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}}});
 addEventListener('resize',()=>set(mobile()&&document.body.classList.contains('admin-menu-open')));set(false);
})();

// LevelEngine 1.1.0 permissions helpers
(()=>{const all=document.querySelector('[data-perms="all"]'),none=document.querySelector('[data-perms="none"]');const boxes=()=>[...document.querySelectorAll('.permission-card input[type="checkbox"]')];all?.addEventListener('click',()=>boxes().forEach(x=>x.checked=true));none?.addEventListener('click',()=>boxes().forEach(x=>x.checked=false));})();

(()=>{const selector=document.querySelector('[data-menu-type]');if(!selector)return;const update=()=>{document.querySelectorAll('[data-menu-target]').forEach(group=>group.hidden=group.dataset.menuTarget!==selector.value)};selector.addEventListener('change',update);update()})();
